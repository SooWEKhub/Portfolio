// Copyright Piotr Sowka, 2022

#pragma once

extern int32 DiffLevel;
extern FString MapLevel;

#include "CoreMinimal.h"
#include "MineSWRBlock.h"


